BAR TICKET PWA

This is a self-contained Safari Progressive Web App for the requested workflow.

Important:
- The app data is stored locally on the iPhone in browser localStorage.
- No cloud subscription is required.
- After first loading it online and installing it to the Home Screen, it is designed to work offline.
- Use Settings > Backup session periodically. Restore is available on the same device or another compatible browser.
- Apple requires a secure HTTPS website for normal PWA installation. A simple static host is sufficient; no database/server is needed.

INSTALL ON IPHONE:
1. Put these files on an HTTPS static website.
2. Open index.html's web address in Safari.
3. Use Safari's Share button -> Add to Home Screen.
4. Launch "Bar Ticket" from the Home Screen.

The five meal prices and five add-on prices start at $0.00. Set them in Settings.

The entry controls intentionally have ONLY one minus sign beneath each item key. Pressing the item key adds one; pressing minus subtracts one.
